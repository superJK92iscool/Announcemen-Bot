﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace Announcement_Bot_Core
{
    class Program
    {

        public static string ver = "4.0.1";
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        public static DiscordSocketClient _client;
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        private CommandService? _commands;
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        public static IServiceProvider _services;
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        public static string prefix = "a!";
        // Main Task for memory fix
        static void Main(string[] args)
        {

            // Must be inside a method
            AppContext.SetSwitch("System.Runtime.EnableLargeArraySupport", true);

            // Example large array allocation that would otherwise fail
            try
            {
                //byte[] bigArray = new byte[2_500_000_000]; // ~2.5 GB
                System.Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Allocation succeeded.");
            }
            catch (OutOfMemoryException ex)

            {
                System.Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Allocation failed: " + ex.Message);
            }
            new Program().RunBot().GetAwaiter().GetResult();
        }
        // Runbot task
        public async Task RunBot()
        {
            var config = new DiscordSocketConfig()
            {
                // Other config options can be presented here.
                GatewayIntents = GatewayIntents.AllUnprivileged | GatewayIntents.MessageContent
            };
            _client = new DiscordSocketClient(config); // Define _client
            _commands = new CommandService(); // Define _commands

            _services = new ServiceCollection() // Define _services
                .AddSingleton(_client)
                .AddSingleton(_commands)
                .BuildServiceProvider();

            string botToken = "NjU4MDQ0NDY0NzQ0MzY2MTEx.GCcNtM.5CGDwFY822B5MVN-w5jDiFMHnNAd4lUujCc1MU"; // Define the bot token

            _client.Log += Log; // Set up logging
            System.Console.ForegroundColor = ConsoleColor.DarkBlue;
            System.Console.WriteLine("   ___                                                            __         ___        __\r\n  / _ |  ___   ___  ___  __ __  ___  ____ ___   __ _  ___   ___  / /_       / _ ) ___  / /_\r\n / __ | / _ \\ / _ \\/ _ \\/ // / / _ \\/ __// -_) /  ' \\/ -_) / _ \\/ __/      / _  |/ _ \\/ __/\r\n/_/ |_|/_//_//_//_/\\___/\\_,_/ /_//_/\\__/ \\__/ /_/_/_/\\__/ /_//_/\\__/      /____/ \\___/\\__/");
            System.Console.ForegroundColor = ConsoleColor.Green;
            System.Console.WriteLine(" ");

            System.Console.WriteLine("Starting");
            System.Console.Write("Version: ");
            System.Console.Write(ver);
            System.Console.WriteLine(" ");
            System.Console.Write("Prefix: ");
            System.Console.Write(prefix);
            System.Console.WriteLine(" ");

            await RegisterCommandsAsync(); // Call registercommands

            await _client.LoginAsync(TokenType.Bot, botToken); // Log into the bot user
            await _client.StartAsync(); // Start the bot user
            await Task.Delay(-1); // Delay for -1 to keep the console window opened

        }

        private async Task RegisterCommandsAsync()
        {
            _client.MessageReceived += HandleCommandAsync; // Messagerecieved
#pragma warning disable CS8602 // Dereference of a possibly null reference.
            await _commands.AddModulesAsync(Assembly.GetEntryAssembly(), null); // Set up the command handler
#pragma warning restore CS8602 // Dereference of a possibly null reference.
        }

        private Task Log(LogMessage arg) // Logging
        {
            System.Console.WriteLine(arg.Message); // Write the log to console
            return Task.CompletedTask; // Return with completedtask
        }

        private async Task HandleCommandAsync(SocketMessage arg)
        {
            var message = arg as SocketUserMessage; // Create a variable with the message as SocketUserMessage
            if (message is null || message.Author.IsBot) return; // Checks if the message is empty or sent by a bot
            int argumentPos = 0; // Sets the argpos to 0 (the start of the message)
            if (message.HasStringPrefix(prefix, ref argumentPos) || message.HasMentionPrefix(_client.CurrentUser, ref argumentPos)) // If the message has the prefix at the start or starts with someone mentioning the bot
            {
                var context = new SocketCommandContext(_client, message); // Create a variable called context
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                var result = await _commands.ExecuteAsync(context, argumentPos, _services); // Create a veriable called result
#pragma warning restore CS8602 // Dereference of a possibly null reference.
            }
        }
    }
}

